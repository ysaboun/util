package com.pwa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwaPushJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
