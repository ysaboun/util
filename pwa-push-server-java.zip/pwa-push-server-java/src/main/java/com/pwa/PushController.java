package com.pwa;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class PushController {

    private final PwaPushService pushService;

    public PushController(PwaPushService pushService) {
        this.pushService = pushService;
    }

    @PostMapping("/subscribe")
    public ResponseEntity<?> subscribe(@RequestBody String subscriptionJson) {
        pushService.addSubscription(subscriptionJson);
        return ResponseEntity.status(201).body("{\"message\": \"Abonnement reçu\"}");
    }

    @PostMapping("/notify")
    public ResponseEntity<?> notifyAll(@RequestBody(required = false) String ignored) {
        pushService.sendNotificationToAll();
        return ResponseEntity.ok("{\"message\": \"Notifications envoyées\"}");
    }
}
