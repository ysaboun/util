package com.pwa;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import nl.martijndwars.webpush.Notification;
import nl.martijndwars.webpush.PushService;
import nl.martijndwars.webpush.Subscription;
import nl.martijndwars.webpush.Utils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.stereotype.Service;

import java.security.Security;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class PwaPushService {

    private final PushService webPushService;
    private final ObjectMapper mapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); // ignore champs inconnus
    private final List<Subscription> subscriptions = new ArrayList<>();

    private final String publicVapidKey = "BJSws7eEA9Mq22_oW7nStP8UVJ2uj15-Bh6cvFkF40hfZx5gM7YwDmuUQ7Sb46BT2rOX5-XiOKE0xjgcpTB733Q";
    private final String privateVapidKey = "qQO-pv5UOrGXeGab5pq7UqQx_ebd3X63y6VojfBU0Q0";

    public PwaPushService() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        webPushService = new PushService();
        webPushService.setPublicKey(Utils.loadPublicKey(publicVapidKey));
        webPushService.setPrivateKey(Utils.loadPrivateKey(privateVapidKey));
        webPushService.setSubject("mailto:admin@example.com");
    }

    /**
     * Transforme le JSON reçu depuis le navigateur en Subscription et l'ajoute à la liste
     * Ignore automatiquement les champs inconnus comme "expirationTime"
     */
    public void addSubscription(String subscriptionJson) {
        try {
            Subscription subscription = mapper.readValue(subscriptionJson, Subscription.class);
            subscriptions.add(subscription);
            System.out.println("📬 Abonnement enregistré : " + subscription.endpoint);
        } catch (Exception e) {
            System.err.println("❌ Erreur parsing abonnement : " + e.getMessage());
        }
    }

    /**
     * Envoie une notification à tous les abonnés et supprime ceux expirés
     */
    public void sendNotificationToAll() {
        String payload = """
                {
                    "title": "Notification PWA",
                    "body": "Votre commande est prête 🎉",
                    "icon": "/icon.png",
                    "data": { "url": "https://example.com" }
                }
                """;

        Iterator<Subscription> iterator = subscriptions.iterator();
        while (iterator.hasNext()) {
            Subscription sub = iterator.next();
            try {
                Notification notification = new Notification(sub, payload);
                webPushService.send(notification);
                System.out.println("✅ Notification envoyée à : " + sub.endpoint);
            } catch (Exception e) {
                // Supprime les abonnements expirés (404 ou 410)
                if (e.getMessage().contains("410") || e.getMessage().contains("404")) {
                    System.out.println("🚫 Abonnement expiré supprimé : " + sub.endpoint);
                    iterator.remove();
                } else {
                    System.err.println("⚠️ Erreur push : " + e.getMessage());
                }
            }
        }
    }
}
