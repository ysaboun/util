package com.example.archunit.controller;

import com.example.archunit.service.UserService;

public class UserController {

    private final UserService userService;

    // Le controller reçoit le service déjà construit (injection externe)
    public UserController(UserService userService) {
        this.userService = userService;
    }

    public String getUserInfo(String userId) {
        return userService.getUserDetails(userId);
    }
}


