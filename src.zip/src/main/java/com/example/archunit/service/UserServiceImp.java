package com.example.archunit.service;

import com.example.archunit.model.User;

public class UserServiceImp implements UserService {
    private final UserRepository userRepository;

    // Injection via constructeur → découplage du connecteur concret
    public UserServiceImp(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public String getUserDetails(String userId) {
        User user = userRepository.findById(userId);
        return user != null
                ? "User: " + user.getName() + " (id=" + user.getId() + ")"
                : "User not found";
    }
}


