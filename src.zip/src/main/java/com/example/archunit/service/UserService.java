package com.example.archunit.service;

public interface UserService {
    String getUserDetails(String userId);
}
