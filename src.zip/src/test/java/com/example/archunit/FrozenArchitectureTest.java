package com.example.archunit;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.library.dependencies.SlicesRuleDefinition;
import com.tngtech.archunit.library.freeze.FreezingArchRule;
import org.junit.jupiter.api.Test;

public class FrozenArchitectureTest {

    @Test
    void connectors_should_not_depend_on_each_other_frozen() {
        JavaClasses importedClasses = new ClassFileImporter()
                .withImportOption(new ImportOption.DoNotIncludeTests())
                .importPackages("com.example");

        ArchRule connectorRule = SlicesRuleDefinition.slices()
                .matching("com.example.*.(connector).(*)")
                .should().notDependOnEachOther()
                .because("Connectors are adapters to external systems");

        // Freezing
        FreezingArchRule.freeze(connectorRule).check(importedClasses);
    }

    @Test
    void services_should_not_depend_on_each_other_frozen() {
        JavaClasses importedClasses = new ClassFileImporter()
                .withImportOption(new ImportOption.DoNotIncludeTests())
                .importPackages("com.example");

        ArchRule serviceRule = SlicesRuleDefinition.slices()
                .matching("com.example.*.(service).(*)")
                .should().notDependOnEachOther()
                .because("Services should be independent");

        FreezingArchRule.freeze(serviceRule).check(importedClasses);
    }
}
