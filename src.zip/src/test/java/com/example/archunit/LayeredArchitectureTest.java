package com.example.archunit;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.core.importer.ImportOption.DoNotIncludeTests;
import com.tngtech.archunit.core.importer.ImportOption.DoNotIncludeJars;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.library.Architectures;
import org.junit.jupiter.api.Test;

import static com.tngtech.archunit.core.domain.JavaClass.Predicates.resideInAPackage;
import static com.tngtech.archunit.library.Architectures.layeredArchitecture;

public class LayeredArchitectureTest {
    private static final String CONTROLLERS_LAYER = "Controllers";
    private static final String SERVICES_LAYER = "Services";
    private static final String CONNECTORS_LAYER = "Connector";

    @Test
    public void checkLayeredArchitecture() {
       JavaClasses importedClasses = new ClassFileImporter()
                .withImportOption(new DoNotIncludeTests())
                .withImportOption(new DoNotIncludeJars())
                .importPackages("com.example");

        Architectures.LayeredArchitecture architecture = (Architectures.LayeredArchitecture) layeredArchitecture()
                .as("Layer dependencies are respected")

                .layer(CONTROLLERS_LAYER).definedBy("com.example.*.controller..")
                .layer(SERVICES_LAYER).definedBy("com.example.*.service..")
                .layer(CONNECTORS_LAYER).definedBy("com.example.*.connector..")

                .whereLayer(CONTROLLERS_LAYER).mayNotBeAccessedByAnyLayer()
                .whereLayer(SERVICES_LAYER).mayOnlyBeAccessedByLayers(CONTROLLERS_LAYER,CONNECTORS_LAYER)
                .whereLayer(CONNECTORS_LAYER).mayNotBeAccessedByAnyLayer()

                .ignoreDependency(resideInAPackage("..stage.."), DescribedPredicate.alwaysTrue())

                .because("Services layer should concentrate business logic and not be infected by interfaces with external systems");


        architecture.check(importedClasses);
    }
}

