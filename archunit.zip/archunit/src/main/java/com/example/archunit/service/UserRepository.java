package com.example.archunit.service;

import com.example.archunit.model.User;

public interface UserRepository {
    User findById(String userId);
}
