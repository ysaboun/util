package com.example.archunit.connector;

import com.example.archunit.model.User;
import com.example.archunit.service.UserRepository;

public class ExternalUserRepository implements UserRepository {

    @Override
    public User findById(String userId) {
        // Simulation d’appel externe (BDD, API, etc.)
        return new User(userId, "user");
    }
}
