package com.example.archunit;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition;

import com.tngtech.archunit.core.domain.JavaClass;
import static com.tngtech.archunit.core.domain.JavaClass.Predicates.resideInAPackage;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.library.Architectures.layeredArchitecture;
import static com.tngtech.archunit.library.dependencies.SlicesRuleDefinition.slices;

public final class LayeredArchitectureRules {

    private static final String CONTROLLERS_LAYER = "Controllers";
    private static final String SERVICES_LAYER = "Services";
    private static final String CONNECTORS_LAYER = "Connector";

    @ArchTest
    public static ArchRule service_layer_dependencies_are_respected = layeredArchitecture()
            .as("Layer dependencies are respected")

            .layer(CONTROLLERS_LAYER).definedBy("com.example.*.controller..")
            .layer(SERVICES_LAYER).definedBy("com.example.*.service..")
            .layer(CONNECTORS_LAYER).definedBy("com.example.*.connector..")

            .whereLayer(CONTROLLERS_LAYER).mayNotBeAccessedByAnyLayer()
            .whereLayer(SERVICES_LAYER).mayOnlyBeAccessedByLayers(CONTROLLERS_LAYER,CONNECTORS_LAYER)
            .whereLayer(CONNECTORS_LAYER).mayNotBeAccessedByAnyLayer()

            .ignoreDependency(resideInAPackage("..stage.."), DescribedPredicate.alwaysTrue())

            .because("Services layer should concentrate business logic and not be infected by interfaces with external systems");


    @ArchTest
    public static ArchRule connectors_do_not_depend_on_one_another = slices()
            .matching("com.example.*.(connector).(*)").namingSlices("$1 '$2'")
            .as("Connectors should not depend on one another")
            .should().notDependOnEachOther()
            .because("Connectors are adapters that isolate dependencies towards external systems");

    @ArchTest
    public static ArchRule services_do_not_depend_on_one_another = slices()
            .matching("com.example.*.(service).(*)").namingSlices("$1 '$2'")
            .as("Services should not depend on one another")
            .should().notDependOnEachOther()
            .because("Services should be split so that they do not depend on one another");

    @ArchTest
    public static ArchRule services_must_not_depend_on_controllers_transitively =  ArchRuleDefinition.noClasses()
            .that().resideInAPackage("..service..")
            .should().dependOnClassesThat().resideInAPackage("..controller..");

    @ArchTest
    public static ArchRule services_should_depend_on_interfaces_not_implementations =
            classes().that().resideInAPackage("..service..")
                    .should().onlyDependOnClassesThat(
                            new DescribedPredicate<JavaClass>("interface or allowed package") {
                                @Override
                                public boolean apply(JavaClass javaClass) {
                                    return javaClass.isInterface()
                                            || javaClass.getPackageName().startsWith("com.example.archunit.model")
                                            || javaClass.getPackageName().startsWith("com.example.archunit.repository")
                                            || javaClass.getPackageName().startsWith("java");
                                }
                            }
                    );

}