# ArchUnit PoC - Architecture Layered Enforcement

Ce projet est un **PoC (Proof of Concept)** d’utilisation d’**ArchUnit** pour vérifier la conformité d’une architecture en couches dans une application Java.

---

## 🏗️ Objectif

L’objectif est de s’assurer que les dépendances entre les packages respectent les principes de l’architecture hexagonale / DDD :

1. **Controller** : couche exposant l’API, ne doit dépendre que des **Services**.
2. **Service** : contient la logique métier, dépend uniquement de **connecteurs via des interfaces**.
3. **Connector** : implémentations des adaptateurs vers des systèmes externes, ne doit pas dépendre d’autres couches.

Ainsi, le code reste **maintenable, testable et découplé**.

---

## 🔹 Structure des packages
com.example
├─ controller
├─ service
│ └─ UserService.java
│ └─ UserRepository.java (interface)
└─ connector
└─ ExternalUserRepository.java

---

## 🧪 Tests ArchUnit

Le projet contient plusieurs types de tests pour vérifier l’architecture :

### 1️⃣ Layered Architecture

Vérifie que les dépendances respectent les couches :

```java
Controller -> Service -> Connector
Controller ❌ Connector
Service ❌ Controller / Connector direct

Fichier : LayeredArchitectureTest.java / LayeredArchitectureRules.java

2️⃣ Domain / Application Independence

Vérifie que :

Le domaine (service) ne dépend pas du controller ou des connectors.

Le service reste autonome et découplé des couches externes.

Fichier : ArchUnitTest.java

3️⃣ Slices (Micro-dependencies)

Vérifie que :

Les connectors ne dépendent pas entre eux.

Les services ne dépendent pas entre eux.

Fichier : LayeredArchitectureRules.java


⚡ Pourquoi ArchUnit est important

ArchUnit permet de tester l’architecture de manière automatisée, en garantissant que :

Les règles de découpage en couches sont respectées.

Les dépendances interdites sont détectées avant production.

Le code reste maintenable, évolutif et compréhensible.µ
































