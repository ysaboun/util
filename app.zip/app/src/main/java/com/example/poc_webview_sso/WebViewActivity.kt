package com.example.poc_webview_sso

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class WebViewActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_webview)

        // 🔍 Active le debug WebView (Chrome: chrome://inspect)
        WebView.setWebContentsDebuggingEnabled(true)
        val webView = findViewById<WebView>(R.id.webview)

        // Configuration recommandée
        with(webView.settings) {
            webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        webView.webChromeClient = WebChromeClient()

        // Unique WebViewClient avec gestion onPageFinished
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val appToken = "MY_SECRET_TOKEN"
                val script = """
                    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
                        navigator.serviceWorker.controller.postMessage('app_token=$appToken');
                    }
                """.trimIndent()
                view?.evaluateJavascript(script) {
                    Toast.makeText(applicationContext, "Token envoyé au service worker", Toast.LENGTH_SHORT).show()
                }
            }

            // ⚠️ Pour contourner les erreurs SSL (seulement en dev !)
            override fun onReceivedSslError(
                view: WebView,
                handler: android.webkit.SslErrorHandler,
                error: android.net.http.SslError
            ) {
                handler.proceed() // ⚠️ Ne jamais faire ça en prod ! Risque de sécurité
            }


            // ✅ Pour laisser WebView gérer toutes les URL (pas ouvrir navigateur externe)
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                return false
            }
        }

        // ⚠️ Utilise bien http si HTTPS échoue
        webView.loadUrl("https://10.0.2.2:3000/")
    }
}
