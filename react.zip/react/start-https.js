const https = require('https');
const fs = require('fs');
const handler = require('serve-handler');
const path = require('path');

const options = {
  key: fs.readFileSync('certs/server.key'),
  cert: fs.readFileSync('certs/server.crt'),
};

const server = https.createServer(options, (req, res) => {
  if (req.url === '/sw.js') {
    // Assurez-vous que sw.js est dans le dossier public
    res.writeHead(200, { 'Content-Type': 'application/javascript' });
    fs.createReadStream(path.join(__dirname, 'public', 'sw.js')).pipe(res);
  } else {
    // Gérer les autres requêtes avec serve-handler
    return handler(req, res, {
      public: path.resolve(__dirname, 'build'), // le répertoire build de ton app React
    });
  }
});

server.listen(3001, () => {
  console.log('✅ HTTPS server running at https://localhost:3001');
});
