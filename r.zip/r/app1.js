import React, { useEffect, useState } from 'react';
import './App.css';  

function App() {
  const [token, setToken] = useState(null);
  const [ackToken, setAckToken] = useState(null);  // Nouveau state pour afficher le token reçu du service worker

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      // Enregistrement du service worker
      navigator.serviceWorker.register('/sw.js')
        .then((registration) => {
          console.log('Service Worker enregistré:', registration);
        })
        .catch((error) => {
          console.log('Erreur d\'enregistrement du Service Worker:', error);
        });

      // Écoute des messages provenant du service worker
      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data?.type === 'TOKEN_RECEIVED') {
          console.log('[SPA] Token reçu du Service Worker:', event.data.token);
          // Mise à jour du state avec le token reçu du service worker
          setAckToken(event.data.token);
        }
      });
    }

    // Écoute des messages provenant de WebView (par exemple, un iframe)
    window.addEventListener('message', (event) => {
      if (event.data?.type === 'ACCESS_TOKEN') {
        console.log('[SPA] Token reçu de WebView :', event.data.token);
        
        // Met à jour le state avec le token
        setToken(event.data.token);
        
        // Envoi du token vers le Service Worker (via fetch)
        /*fetch('/token-sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: event.data.token }),
        })
        .then(response => {
          if (!response.ok) {
            throw new Error('Erreur lors de l\'envoi du token');
          }
          return response.text();
        })
        .then(data => {
          console.log('Réponse du service worker:', data);
        })
        .catch(error => {
          console.error('Erreur lors de l\'envoi du token au service worker:', error);
        });
        */


      }
    });

  }, []);

  const handleButtonClick = () => {
    if (navigator.serviceWorker.controller && token) {
      // Envoi du token dynamique via fetch vers /token-sync
      fetch('/token-sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: token })
      })
      .then(response => response.text())
      .then(data => {
        console.log('Réponse du service worker:', data);
      })
      .catch(error => {
        console.error('Erreur lors de l\'envoi du token au service worker:', error);
      });
    } else {
      console.log('Pas de token disponible ou Service Worker non contrôlé');
    }
  };

  return (
    <div>
      <h5>Token reçu depuis WebView</h5>
      <p id="token-display">Token reçu: {token || '(aucun)'}</p>
      
      <h5>Messages provenant du Service Worker</h5>
      <p id="ack-message">Token reçu côté service worker: {ackToken || '(aucun)'}</p>
      
      <button id="data_api_with_token" onClick={handleButtonClick}>Envoyer avec Token</button>
    </div>
  );
}

export default App;
