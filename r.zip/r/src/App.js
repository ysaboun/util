import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [token, setToken] = useState(null);
  const [ackToken, setAckToken] = useState(null);
  const [logs, setLogs] = useState([]);
  const [isTokenReceived, setIsTokenReceived] = useState(false);
  const [isTokenSent, setIsTokenSent] = useState(false);
  const [isServiceWorkerRegistered, setIsServiceWorkerRegistered] = useState(false);

  const logMessage = (message) => {
    const timestamp = new Date().toLocaleTimeString();
    const log = `[${timestamp}] ${message}`;
    setLogs(prev => {
      if (prev[prev.length - 1] !== log) return [...prev, log];
      return prev;
    });
  };

  const sendTokenToSW = (tokenToSend) => {
    logMessage(`🔄 (Re)Envoi du token au Service Worker via fetch : ${tokenToSend}`);
    fetch('/token-sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: tokenToSend }),
    })
      .then(res => res.text())
      .then(data => {
        logMessage(`✅ Réponse du Service Worker : ${data}`);
        setAckToken(tokenToSend);
      })
      .catch(err => {
        logMessage(`❌ Erreur lors de l'envoi au SW : ${err.message}`);
      });
  };

  const notifyNativeAppTokenExpired = () => {
    const message = JSON.stringify({ type: 'tokenExpired' });
  
    // Android natif (interface Java)
    if (window.AndroidBridge?.onTokenExpired) {
      window.AndroidBridge.onTokenExpired();
    }
  
    // iOS natif (WKWebView)
    if (window.webkit?.messageHandlers?.bridge?.postMessage) {
      window.webkit.messageHandlers.bridge.postMessage({ type: 'tokenExpired' });
    }
  
    // React Native (Android/iOS)
    if (window.ReactNativeWebView?.postMessage) {
      window.ReactNativeWebView.postMessage(message);
    }
  
    // WebView ou iframe fallback (utile pour debug ou plateforme web hybride)
    window.postMessage(message, '*');
  };
  
  

  const handleApiCall = () => {
    logMessage('📞 Appel API déclenché...');
    //fetch('https://httpbin.org/bearer')
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => {
        if (res.status === 401) {
          //logMessage('⚠️ 401 reçu : token expiré. Côté Kotlin, le renouvellement est en cours...');
          logMessage('⚠️ 401 reçu : appel AndroidBridge.onTokenExpired()');
          if (window.AndroidBridge?.onTokenExpired) {
            window.AndroidBridge.onTokenExpired();
          }
          //notifyNativeAppTokenExpired();
        } else {
          return res.json().then(data => {
            logMessage(`✅ Données API : ${JSON.stringify(data)}`);
          });
        }
      })
      .catch(err => {
        logMessage(`❌ Erreur API : ${err.message}`);
      });
  };

  useEffect(() => {
    if ('serviceWorker' in navigator && !isServiceWorkerRegistered) {
      navigator.serviceWorker.register('/sw.js')
        .then(() => {
          logMessage('✅ SW enregistré.');
          setIsServiceWorkerRegistered(true);
        })
        .catch((error) => {
          logMessage(`❌ Échec SW : ${error}`);
        });

      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data?.type === 'TOKEN_EXPIRED') {
          logMessage('⚠️ Le token a expiré. Renouvellement nécessaire.');
          // Vous pouvez ajouter ici le renouvellement du token
        } else if (event.data?.type === 'TOKEN_RECEIVED') {
          setAckToken(event.data.token);
          logMessage(`✅ SW a bien reçu le token : ${event.data.token}`);
        }
      });
    }

    window.addEventListener('message', (event) => {
      if (event.data?.type === 'ACCESS_TOKEN' && !isTokenReceived) {
        const receivedToken = event.data.token;
        logMessage(`🔑 Token WebView : ${receivedToken}`);
        setToken(receivedToken);
        setIsTokenReceived(true);
        if (!isTokenSent) {
          sendTokenToSW(receivedToken);
          setIsTokenSent(true);
        }
      }
    });

    return () => window.removeEventListener('message', () => {});
  }, [isTokenReceived, isTokenSent, isServiceWorkerRegistered]);

  return (
    <div className="container">
      <h5>Token reçu de la WebView</h5>
      <p>Token : {token || '(aucun token)'}</p>

      <h5>Token dans le Service Worker</h5>
      <p>{ackToken || '(aucun token SW)'}</p>

      <button onClick={handleApiCall}>📞 Call API</button>

      <h5>Logs</h5>
      <textarea className="log-area" value={logs.join('\n')} readOnly rows={12} />
    </div>
  );
}

export default App;
