self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open('my-spa-cache').then((cache) => {
      return cache.addAll([
        '/',
        '/index.html',
        '/static/js/main.0a0a6d1f.js', // ajuste si le hash a changé
      ]);
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// 🔐 Mémoire locale du SW (pas persistante)
self._accessToken = null;

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // 🎯 TOKEN SYNC
  if (url.pathname === '/token-sync' && event.request.method === 'POST') {
    event.respondWith(
      (async () => {
        try {
          const data = await event.request.clone().json();
          const token = data.token;
          self._accessToken = token;

          console.log('[SW] Token reçu et stocké en mémoire:', token);

          const clients = await self.clients.matchAll();
          clients.forEach(client =>
            client.postMessage({ type: 'TOKEN_RECEIVED', token })
          );

          return new Response('Token enregistré');
        } catch (err) {
          return new Response('Erreur lors de la lecture du token', { status: 400 });
        }
      })()
    );
    return;
  }

  // 🔐 API AVEC TOKEN
  if (url.pathname.startsWith('/bearer') && self._accessToken) {
    
    event.respondWith(
      (async () => {
        const headers = new Headers(event.request.headers);
        if (self._accessToken) {
          headers.set('Authorization', `Bearer ${self._accessToken}`);
        }

        const authRequest = new Request(event.request.url, {
          method: event.request.method,
          headers: headers,
          body: event.request.method !== 'GET' && event.request.method !== 'HEAD'
            ? await event.request.clone().blob()
            : undefined,
          mode: event.request.mode,
          credentials: event.request.credentials,
          redirect: event.request.redirect,
          referrer: event.request.referrer,
          referrerPolicy: event.request.referrerPolicy,
          integrity: event.request.integrity,
          cache: event.request.cache,
        });

        const response = await fetch(authRequest);
          // Si réponse 401 (token expiré), envoyer un message au client
           // Simulation de la réponse 401 (Token expiré)
        /*const mockResponse = {
          status: 401,
          json: () => Promise.resolve({ message: 'Token expiré' }),
        };*/

        //const response = mockResponse;

         // Retourne la réponse mockée 401
         //return mockResponse;

        /*if (response.status === 401) {
          // Envoi d'un message à l'application principale pour signaler un token expiré
          const clients = await self.clients.matchAll();
          clients.forEach(client =>
            client.postMessage({ type: 'TOKEN_EXPIRED', message: 'Token expiré. Renouvellement nécessaire.' })
          );
        }
  */
          return response;
          
      })()
    );
    return;
  }


  // 🌐 PAR DÉFAUT : retourne du cache ou passe au réseau
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return cachedResponse || fetch(event.request);
    })
  );
});
