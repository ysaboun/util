
# 🎯 Démo PWA Push Notifications

Cette démo montre comment implémenter des **notifications push pour une Progressive Web App (PWA)**.  
Deux versions de backend sont proposées : **Node.js** ou **Java Spring Boot**.

Le projet inclut :

- **Frontend** : `index.html` pour s’abonner aux notifications.
- **Service Worker** : `sw.js` pour gérer la réception et l’affichage des notifications.
- **Backend Node.js** : serveur Express avec `web-push`.
- **Backend Java** : Spring Boot + `nl.martijndwars:web-push` + BouncyCastle.

---

## 🛠 Prérequis

- Node.js >= 18 (pour backend Node.js)
- Java 17+ et Maven (pour backend Spring Boot)
- Navigateur moderne (Chrome, Firefox, Edge) avec support Service Worker et Push API
- HTTPS en production (localhost autorisé en HTTP pour dev)

---

## 🔧 Installation (Frontend PWA)

1. Placer les fichiers `index.html` et `sw.js` dans le dossier `public/` ou `src/main/resources/static/` pour Java.  
2. Modifier la clé publique VAPID dans `index.html` :

```javascript
const publicVapidKey = '<votre_clé_publique>';
```

3. Modifier l’URL du backend :

```javascript
const apiBase = 'http://localhost:3000'; // Node.js
// ou
const apiBase = 'http://localhost:8080'; // Java Spring Boot
```

---

## ⚡ Backend Node.js

### Installation

```bash
npm install express web-push body-parser
npx web-push generate-vapid-keys
```

### Lancer le serveur

```bash
node server.js
```

- Serveur par défaut sur `http://localhost:3000`  
- Endpoints :  
  - `POST /subscribe` : enregistre un abonnement push  
  - `POST /notify` : envoie une notification à tous les abonnés

### Exemple `server.js`

```javascript
const express = require('express');
const bodyParser = require('body-parser');
const webpush = require('web-push');
const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

const publicVapidKey = '<votre_clé_publique>';
const privateVapidKey = '<votre_clé_privée>';

webpush.setVapidDetails('mailto:admin@example.com', publicVapidKey, privateVapidKey);
let subscriptions = [];

app.post('/subscribe', (req, res) => {
  const subscription = req.body;
  subscriptions.push(subscription);
  res.status(201).json({ message: 'Abonnement reçu' });
});

app.post('/notify', async (req, res) => {
  const payload = JSON.stringify({ title: 'Notification PWA', body: 'Votre commande est prête 🎉', icon: '/icon.png', data: { url: 'https://example.com' } });
  await Promise.all(subscriptions.map(sub => webpush.sendNotification(sub, payload).catch(console.error)));
  res.json({ message: 'Notifications envoyées' });
});

app.listen(3000, () => console.log('Serveur Node.js prêt sur http://localhost:3000'));
```

---

## ⚡ Backend Java Spring Boot

### Installation

- Maven et Java 17+
- Dépendances principales :
  - `org.springframework.boot:spring-boot-starter-web`
  - `nl.martijndwars:web-push`
  - `org.bouncycastle:bcprov-jdk15on`

### Lancer le serveur

```bash
mvn spring-boot:run
```

- Serveur par défaut sur `http://localhost:8080`
- Endpoints :
  - `POST /subscribe` : enregistre un abonnement push
  - `POST /notify` : envoie une notification à tous les abonnés

### Exemple `PwaPushService.java`

```java
@Service
public class PwaPushService {
    private final PushService webPushService;
    private final ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    private final List<Subscription> subscriptions = new ArrayList<>();

    private final String publicVapidKey = "<votre_clé_publique>";
    private final String privateVapidKey = "<votre_clé_privée>";

    public PwaPushService() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        webPushService = new PushService();
        webPushService.setPublicKey(Utils.loadPublicKey(publicVapidKey));
        webPushService.setPrivateKey(Utils.loadPrivateKey(privateVapidKey));
        webPushService.setSubject("mailto:admin@example.com");
    }

    public void addSubscription(String subscriptionJson) {
        try {
            Subscription subscription = mapper.readValue(subscriptionJson, Subscription.class);
            subscriptions.add(subscription);
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void sendNotificationToAll() {
        String payload = "{ "title":"Notification PWA", "body":"Votre commande est prête 🎉" }";
        Iterator<Subscription> it = subscriptions.iterator();
        while (it.hasNext()) {
            Subscription sub = it.next();
            try { webPushService.send(new Notification(sub, payload)); } 
            catch (Exception e) { it.remove(); }
        }
    }
}
```

---

## 🖥 Fonctionnement général

1. **Frontend (`index.html`)** :

- Enregistre le Service Worker (`sw.js`)
- Demande la permission de notifications
- S’abonne au PushManager et envoie l’abonnement au backend

2. **Service Worker (`sw.js`)** :

- Écoute les événements `push` et affiche la notification
- Gère le clic sur la notification pour ouvrir un lien associé

3. **Backend (Node.js ou Java)** :

- Stocke les abonnements
- Envoie des notifications via `web-push`
- Supprime les abonnements expirés

---

## ⚠️ Points importants

- Notifications push **nécessitent HTTPS** en production
- Abonnements stockés **en mémoire** pour cette démo
- Pour production : utiliser une base de données et gérer les abonnements expirés
- Respecter le RGPD : ne stocker que les données nécessaires et ne jamais exposer les endpoints ou clés côté client
