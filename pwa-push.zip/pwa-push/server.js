const express = require('express');
const bodyParser = require('body-parser');
const webpush = require('web-push');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

// 🔐 Clés VAPID — à générer avec `npx web-push generate-vapid-keys`
const publicVapidKey = 'BJSws7eEA9Mq22_oW7nStP8UVJ2uj15-Bh6cvFkF40hfZx5gM7YwDmuUQ7Sb46BT2rOX5-XiOKE0xjgcpTB733Q';
const privateVapidKey = 'qQO-pv5UOrGXeGab5pq7UqQx_ebd3X63y6VojfBU0Q0';

webpush.setVapidDetails(
  'mailto:admin@example.com',
  publicVapidKey,
  privateVapidKey
);

// Stockage temporaire en mémoire
let subscriptions = [];

// Enregistrer un abonnement
app.post('/subscribe', (req, res) => {
  const subscription = req.body;
  if (!subscription || !subscription.endpoint) {
    return res.status(400).json({ error: 'Abonnement invalide' });
  }
  subscriptions.push(subscription);
  console.log('📬 Nouvel abonnement enregistré :', subscription.endpoint);
  res.status(201).json({ message: 'Abonnement reçu' });
});

// Envoyer une notification à tous les abonnés
app.post('/notify', async (req, res) => {
  const payload = JSON.stringify({
    title: 'Notification PWA',
    body: 'Votre commande est prête 🎉',
    icon: '/icon.png',
    data: { url: 'https://example.com' }
  });

  try {
    await Promise.all(
      subscriptions.map(sub =>
        webpush.sendNotification(sub, payload).catch(err => {
          if (err.statusCode === 404 || err.statusCode === 410) {
            console.log('🚫 Abonnement expiré, suppression.');
            subscriptions = subscriptions.filter(s => s !== sub);
          } else {
            console.error('Erreur push :', err);
          }
        })
      )
    );
    res.status(200).json({ message: 'Notifications envoyées' });
  } catch (error) {
    console.error('Erreur envoi push :', error);
    res.status(500).json({ error: 'Erreur lors de l’envoi' });
  }
});

app.listen(3000, () => {
  console.log('🚀 Serveur prêt sur http://localhost:3000');
});