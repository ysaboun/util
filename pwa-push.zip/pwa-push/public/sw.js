self.addEventListener('push', event => {
  if (!event.data) return;
  const data = event.data.json();

  const options = {
    body: data.body,
    icon: data.icon,
    badge: data.icon,
    data: data.data,
    vibrate: [100, 50, 100],
    // Couleur violette (certaines plateformes utilisent 'badge' ou 'actions' pour teintes)
    actions: [{ action: 'open', title: 'Voir', icon: '/icon.png' }]
  };

  event.waitUntil(self.registration.showNotification(data.title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data && event.notification.data.url;
  if (url) event.waitUntil(clients.openWindow(url));
});
