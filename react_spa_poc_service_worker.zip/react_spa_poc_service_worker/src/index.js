// src/index.js
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';  // Optionnel, mais vous pouvez inclure votre style de base
import App from './App';  // Votre composant principal

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')  // Assurez-vous que votre index.html contient un élément avec l'ID 'root'
);
