
import React, { useEffect } from 'react';

function App() {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').then((registration) => {
        console.log('Service Worker enregistré:', registration);
      }).catch((error) => {
        console.log('Erreur denregistrement du Service Worker:', error);
      });

      // 🎯 Réception du token et affichage
    navigator.serviceWorker.addEventListener('message', (event) => {
      if (event.data?.type === 'APP_TOKEN') {
        const token = event.data.token;
        const display = document.getElementById('token-display');
        if (display) {
          display.textContent = `Token reçu: ${token}`;
        }
      }
    });
    }
  }, []);

  const handleButtonClick = () => {
    if (navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage('app_token=MY_SECRET_TOKEN');
    }
  };

  return (
    <div>
      <button id="data_api_with_token" onClick={handleButtonClick}>Envoyer avec Token</button>
    </div>
  );
}

export default App;
