
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open('my-spa-cache').then((cache) => {
      return cache.addAll(['/', '/index.html', '/static/js/bundle.js']);
    })
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('/api')) {
    event.respondWith(
      fetch(event.request).then((response) => {
        const clonedResponse = response.clone();
        clonedResponse.text().then((text) => {
          console.log("Reponse API:", text);
        });
        return response;
      })
    );
  }
});

self.addEventListener('message', (event) => {
  let token = null;

  if (typeof event.data === 'string' && event.data.startsWith("app_token=")) {
    token = event.data.split('=')[1];
  } else if (event.data?.type === 'APP_TOKEN') {
    token = event.data.token;
  }

  if (token) {
    // Transmet le token aux pages clientes
    self.clients.matchAll().then(clients => {
      clients.forEach(client => {
        client.postMessage({ type: 'APP_TOKEN', token });
      });
    });
  }
});



