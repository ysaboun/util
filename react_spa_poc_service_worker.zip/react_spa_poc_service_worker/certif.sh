# 1. Crée une autorité de certification (CA)
openssl genrsa -out my_rootCA.key 2048
openssl req -x509 -new -nodes -key my_rootCA.key -sha256 -days 1024 -out my_rootCA.pem \
  -subj "/C=FR/ST=Paris/L=Paris/O=DevTest/CN=MyDevRootCA"

# 2. Crée une clé privée pour ton serveur React
openssl genrsa -out server.key 2048

# 3. Crée une demande de signature (CSR)
openssl req -new -key server.key -out server.csr \
  -subj "/C=FR/ST=Paris/L=Paris/O=DevReact/CN=10.0.2.2"

# 4. Crée un fichier de configuration avec le SAN (Subject Alternative Name)
echo "subjectAltName=IP:10.0.2.2" > san.ext

# 5. Signe le certificat avec ta CA
openssl x509 -req -in server.csr -CA my_rootCA.pem -CAkey my_rootCA.key -CAcreateserial \
  -out server.crt -days 500 -sha256 -extfile san.ext

# 6. Convertis my_rootCA.pem vers .crt au format DER :
openssl x509 -in my_rootCA.pem -out my_rootCA.crt -outform DER

